//
//  degree.h
//  Student Data
//
//  Created by DeAundra Dyson on 7/2/20.
//  Copyright © 2020 DeAundra Dyson. All rights reserved.
//
#ifndef degree_h
#define degree_h

enum Degree {SECURITY, NETWORKING, SOFTWARE };

#endif /* degree_h */

