//
//  securityStudent.cpp
//  Student Data
//
//  Created by DeAundra Dyson on 7/2/20.
//  Copyright © 2020 DeAundra Dyson. All rights reserved.
//

#include "securityStudent.hpp"
